<?php
$app_strings['LBL_STREETVIEW_DASHLET'] = 'Google Streetview';
$app_strings['LBL_STREETVIEW_DASHLET_DESC'] = 'Set up Google Streetview for a record';